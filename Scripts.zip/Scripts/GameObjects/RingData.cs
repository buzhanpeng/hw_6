﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//表示环的分数
public class RingData : MonoBehaviour {
    public int score = 1;
}
